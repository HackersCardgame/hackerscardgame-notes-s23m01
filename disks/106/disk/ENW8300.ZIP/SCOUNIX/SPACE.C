#include "sys/types.h"
#include "sys/stream.h"
#include "sys/socket.h"
#include "/etc/conf/cf.d/config.h"
/* #include "config.h" */


/* interrupt level per board  */

#if defined(R1E3_UNITS)
#define R1EUNIT 4
ushort r1eicintl[R1EUNIT] =
	{ R1E_0_VECT,R1E1_0_VECT,R1E2_0_VECT,R1E3_0_VECT };
ushort r1eicioaddr[R1EUNIT] =
	{ R1E_0_SIOA,R1E1_0_SIOA,R1E2_0_SIOA,R1E3_0_SIOA };

#elif defined(R1E2_UNITS)
#define R1EUNIT 3
ushort r1eicintl[R0EUNIT] =
	{ R1E_0_VECT,R1E1_0_VECT,R1E2_0_VECT };
ushort r1eicioaddr[R1EUNIT] =
	{ R1E_0_SIOA,R1E1_0_SIOA,R1E2_0_SIOA };


#elif defined(R1E1_UNITS)
#define R1EUNIT 2
ushort r1eicintl[R1EUNIT] = { R1E_0_VECT,R1E1_0_VECT };
ushort r1eicioaddr[R1EUNIT] = { R1E_0_SIOA,R1E1_0_SIOA };


#elif defined(R1E_UNITS)
#define R1EUNIT  1
ushort r1eicintl[R1EUNIT] = { R1E_0_VECT };
ushort r1eicioaddr[R1EUNIT] = { R1E_0_SIOA };
#endif

ushort r1e_BOARDS = R1EUNIT;

