======================================================================

Version 1, created on 23 August 1998

This archive contains some sound patches which I have created for the
Roland JP8000 music synthesizer. They are stored as standard midi
files. Each file contains a single patch.

This archive is freely distributable, but only as a unit, and with my
credit intact.
Check for the latest version here: http://www.best.com/~rpieket/

Enjoy!

Ronald Pieket
rpieket@best.com

======================================================================
